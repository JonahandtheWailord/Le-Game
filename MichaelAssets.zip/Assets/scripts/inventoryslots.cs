using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class inventoryslots : MonoBehaviour, IDropHandler
{
    public Image image;
    public Color selectedcolor, notselectedcolor;

    private void Awake()
    {
        deselect();
    }

    public void select()
    {
        image.color = selectedcolor;
    }

    public void deselect()
    {
        image.color =notselectedcolor;
    }

    public void OnDrop(PointerEventData eventData)
    {
        Debug.Log(eventData.pointerDrag.name);
        if(transform.childCount == 0)
        {
            Debug.Log("Or here?");
            inventoryitem inventoryitme = eventData.pointerDrag.GetComponent<inventoryitem>();
            inventoryitme.parentafterDrag = transform;

        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
