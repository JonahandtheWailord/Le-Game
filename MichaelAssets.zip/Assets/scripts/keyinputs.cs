using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using static UnityEditor.Progress;

public class keyinputs : MonoBehaviour
{
    public Tilemap[] tilemap;

    public static Tilemap[] statictilemap;

    public TileBase[] placing;

    public GameObject inventorySlotPrefab; // Prefab/UI element representing an inventory slot

    public GameObject interactionsprefab;


    private void Start()
    {
        statictilemap = tilemap;
    }

    // Update is called once per frame
    void Update()
    {

        if (Keyboard.current.zKey.wasPressedThisFrame)
        {
            if (daynight.timepause)
            {
                Debug.Log("unpause");
                daynight.timepause = false;
            }
            else
            {
                Debug.Log("paused");
            daynight.timepause = true;
            }

        }
            if (Keyboard.current.qKey.wasPressedThisFrame)
        {
            // Convert the hit point to tile coordinates
            Vector3Int cellPosition = playercontroller.position;
            TileBase tile = playercontroller.tilebase;
            if (playercontroller.interacting == null)
            {                     
                    Vector3Int rbposition = tilemap[1].WorldToCell(playercontroller.rb.position);
                    planting.plantingplant(tilemap, rbposition, placing);

            }
            else
            {

                if (tile != null && playercontroller.interacting.gameObject.name == "items")
                {
                    Debug.Log(((Tile)tile).sprite.name);
                    Items item = inventorymanagement.GetValue(((Tile)tile).sprite.name);
                    Debug.Log(inventorymanagement.GetValue(((Tile)tile).sprite.name));
                    Debug.Log(item.itemName);
                    bool added = inventorymanagement.instance.AddItem(item);
                    if (added)
                    {
                        tilemap[3].SetTile(cellPosition, null);
                        playercontroller.interacting = null;
                    }
                    // remove the tile from the Tilemap



/*                    GameObject slot = Instantiate(inventorySlotPrefab, gameObject.transform);
                    // Create an item instance and add it to the inventory
                    Items item = slot.GetComponent<Items>();
                    item.itemName = ((Tile)tile).sprite.name; // Set item name

                    slot.name = item.itemName;
                    // Set the item's image to the sprite of the tile being destroyed
                    
                    //item.image = ((Tile)tile).sprite;
                    if (item.itemName.Contains("seed"))
                    {
                        Debug.Log("is a seed");
                        slot.tag = "seed";
                    }

                    Image slotImage = slot.GetComponent<Image>();
                    
                    //slotImage.sprite = item.image;

                    Debug.Log("Picked up item: " + item.itemName);*/
                }
                else if (tile != null && playercontroller.interacting.gameObject.name == "people")
                {
                    interactionsprefab.SetActive(true);
                    Debug.Log(((Tile)tile).sprite.name);
                    if (((Tile)tile).sprite.name == "player_11")
                    {
                        player_26.characterdecision();
                    }
                    else if (((Tile)tile).sprite.name == "player_50")
                    {
                        player_50.characterdecision();
                    }
                    playercontroller.interacting = null;
                }
            }
        }
    }
}
