using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class inventoryitem : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public Image image;
    public Transform parentafterDrag;
    public Items item;
    public int count = 1;
    public TextMeshProUGUI counttext;

    void Start()
    {
        Debug.Log(item.image);
        Initializeditem(item);
        image = GetComponent<Image>();
        parentafterDrag = GetComponent<Transform>();
    }

    public void RefreshCount()
    {
        counttext.text = count.ToString();
        bool textactive = count > 1;
        counttext.gameObject.SetActive(textactive);

    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        image.raycastTarget = false;
        counttext.raycastTarget = false;
        parentafterDrag = transform.parent;
        transform.SetParent(transform.root);
    }

    public void Initializeditem(Items newitem)
    {
        item = newitem;
        Debug.Log(newitem.image);
        GetComponent<Image>().sprite = newitem.image;
        RefreshCount();
    }

    public void OnDrag(PointerEventData eventData)
    {
        transform.position = Input.mousePosition;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        image.raycastTarget = true;
        counttext.raycastTarget= true;
        Debug.Log("does it go here");
        transform.SetParent(parentafterDrag);
       
    }

    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
        
    }
}
