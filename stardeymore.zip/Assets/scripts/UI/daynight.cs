using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Rendering.Universal;
using System;

public class daynight : MonoBehaviour
{
    public float duration = 5f;
    public static float time = 0;
    public static float daynighttime = 0;
    public static Boolean timepause = false;
    public static string timeperiod = "";

    [SerializeField] private Gradient gradient;
    private Light2D _light;
    private float _startTime;

    private void Awake()
    {
        _light = GetComponent<Light2D>();
        _startTime = Time.time;
        daynighttime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        if (!timepause)
        {
            time += Time.deltaTime;
        }

        // Calculate the time elapsed since the start time
        var timeElapsed = daynight.time - _startTime;
        // Calculate the percentage based on the sine of the time elapsed
        var percentage = Mathf.Sin(timeElapsed / duration * Mathf.PI * 2) * 0.5f + 0.5f;
        // Clamp the percentage to be between 0 and 1
        percentage = Mathf.Clamp01(percentage);

        _light.color = gradient.Evaluate(percentage);
        switch((int)time % 5) 
        {
           case 1:
                timeperiod = "night";

                break;
            case 2:
                timeperiod = "morning";
                break;
            case 4:
                timeperiod = "evening";

                break;
        }
    }
}
