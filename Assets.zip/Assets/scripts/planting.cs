using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class planting : MonoBehaviour
{
    public GameObject mainplant;
    public static GameObject prefabplant;

    public TileBase[] ogseed;
    public TileBase[] ogmiddle;
    public static List<TileBase[]> tilebases = new List<TileBase[]>();

    public static TileBase[] seed;
    public static TileBase[] middle;
    public static Dictionary<string, int[]> plantmap = new Dictionary<string, int[]>();

    // Start is called before the first frame update
    void Start()
    {
        seed = ogseed;
        middle = ogmiddle;
        prefabplant = mainplant;


        tilebases.Add(seed);
        tilebases.Add(middle);

        Add("Seed", 0, 0);
        Debug.Log(plantmap["Seed"]);
    }

    // Method to add an item to the map with inline array values
    public void Add(string key, params int[] values)
    {
        plantmap.Add(key, values);
    }
    // Update is called once per frame
    void Update()
    {
    }

    public static void plantingplant(Tilemap[] tilemap, Vector3Int rbposition, TileBase[] placing)
    {
        Items item = inventorymanagement.instance.GetSelectedItem(false);
        if (item.itemName == "Hoe")
        {
            Debug.Log("Player position in cell coordinates: " + rbposition);
            tilemap[1].SetTile(rbposition, placing[0]);
        }
        Debug.Log(item.type.ToString());
        if (item.type.ToString() == "seed")
        {
            //this figures out what layer you want
            TileBase dirt = tilemap[1].GetTile(rbposition);
            if (dirt.name == "dirt")
            {
                Debug.Log(seed.Length);
                Debug.Log(seed[GetValue(item.itemName)[0]]);
                tilemap[1].SetTile(rbposition, seed[GetValue(item.itemName)[0]]);
                // Assuming 'allplants' is a List<plants> to store plant data
                GameObject newplant = Instantiate(prefabplant, GameObject.Find("plantscontroller").transform);
                plants plantinfo = newplant.GetComponent<plants>();
                plantinfo.Name = item.itemName;
                plantinfo.iswatered = false;
                plantinfo.isharvestable = false;
                plantinfo.location = rbposition;
                plantinfo.plantedtime = daynight.time;
                inventorymanagement.instance.GetSelectedItem(true);
            }
        }
    }

    public static bool ContainsKey(string key)
    {
        return plantmap.ContainsKey(key);
    }

    public static int[] GetValue(string key)
    {
        if (plantmap.ContainsKey(key))
            return plantmap[key];
        else
            return null; // Or return an empty array or handle as needed
    }
}
