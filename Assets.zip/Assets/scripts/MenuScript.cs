using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Button startButton;
    public Button QuitGame;
    public Canvas canvas;
    public Toggle soundToggle;
    public AudioSource audioSource;
    public PauseManager pauseManager;

    private bool isPaused = false;
    void Start()
    {
        // Add listener to the start button
        startButton.onClick.AddListener(StartGame);

        // Add listener to the close button
        QuitGame.onClick.AddListener(CloseGame);

        soundToggle.onValueChanged.AddListener(ToggleSound);
    }

    void StartGame()
    {
        Debug.Log("Game started!");
        // Add your game start logic here

        PauseManager.instance.Unpause();
    }

    public void CloseGame()
    {
        Debug.Log("Game closed!");
        // Add your game close logic here
        Application.Quit(); // This will close the application (works in standalone builds)
    }
    void Update()
    {
        if (Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            Debug.Log("is it working");
            canvas.enabled = true;
            PauseManager.instance.Pause();


        }

    }
    public void ToggleSound(bool isSoundOn)
    {
        if (isSoundOn)
        {
            Debug.Log("is it sound");
            audioSource.volume = 1f; // Unmute sound
        }
        else
        {
            Debug.Log("is it sound");
            audioSource.volume = 0f; // Mute sound
        }
    }
    

}
