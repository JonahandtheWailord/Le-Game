using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseManager : MonoBehaviour
{
    // Static reference to the PauseManager instance
    public static PauseManager instance;

    // Variable to keep track of whether the game is paused
    private bool isPaused = false;

    void Awake()
    {
        // Ensure there's only one instance of PauseManager in the scene
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Update()
    {
        // Check for user input to toggle pause state
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePause();
        }
    }

    // Method to toggle pause state
    public void TogglePause()
    {
        isPaused = !isPaused;

        // If the game is paused, set the time scale to 0 to pause all activities
        // If the game is unpaused, set the time scale back to 1 to resume activities
        Time.timeScale = isPaused ? 0 : 1;
    }

    // Method to explicitly pause the game
    public void Pause()
    {
        isPaused = true;
        Time.timeScale = 0;
    }

    // Method to explicitly unpause the game
    public void Unpause()
    {
        isPaused = false;
        Time.timeScale = 1;
    }
}
