using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class raining : MonoBehaviour
{
    public ParticleSystem ParticleSystem;
    public GameObject player;
    bool stopped = false;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {
        if (Keyboard.current.pKey.wasPressedThisFrame)
        {
            ParticleSystem.enableEmission = true;
            stopped = false;
        }
        if (Keyboard.current.oKey.wasPressedThisFrame)
        {
            ParticleSystem.enableEmission = false;
            stopped = true;
        }

        playercontroller playerInfo = player.GetComponent<playercontroller>();
        if(stopped == false)
        {
            if (playerInfo.velocity.y < 0)
            {
                
            }
            else if (playerInfo.velocity.y > 0)
            {
               
            }
        }
    }
}
