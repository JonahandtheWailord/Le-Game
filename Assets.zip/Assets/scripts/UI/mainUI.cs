using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using static UnityEditor.Progress;

public class mainUI : MonoBehaviour
{
    public static int money = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        GameObject.Find("money").GetComponent<TextMeshProUGUI>().text = "money: " + money;
    }
}
