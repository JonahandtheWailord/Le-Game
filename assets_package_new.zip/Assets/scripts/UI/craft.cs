using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class craft : MonoBehaviour
{
    // Define a custom class to represent a crafting recipe
    public class CraftingRecipe
    {
        public List<Items> RequiredItems { get; }

        public CraftingRecipe(List<Items> requiredItems)
        {
            RequiredItems = requiredItems.ToList();
        }

        // Override Equals and GetHashCode for custom comparison
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            CraftingRecipe other = (CraftingRecipe)obj;

            // Compare the sets of required items
            return RequiredItems.Count == other.RequiredItems.Count &&
                   RequiredItems.All(item => other.RequiredItems.Contains(item));
        }

        public override int GetHashCode()
        {
            return RequiredItems.Select(item => item.GetHashCode()).Aggregate((hash1, hash2) => hash1 ^ hash2);
        }
    }

    // Dictionary using CraftingRecipe as the key
    public Dictionary<CraftingRecipe, Items> craftables = new Dictionary<CraftingRecipe, Items>();

    public Items[] allItems;


    public CraftingRecipe createrecipe(params Items[] allItems)
    {
        List<Items> items = new List<Items>();
        foreach (Items item in allItems)
        {
            items.Add(item);
        }
        return new CraftingRecipe(items);
    }
    void Start()
    {
        // Example usage: adding crafting recipes to the dictionary
        craftables.Add(createrecipe(allItems[1], allItems[2]), allItems[1]);
        craftables.Add(createrecipe(allItems[0], allItems[1]), allItems[1]);
        craftables.Add(createrecipe(allItems[1], allItems[1]), allItems[0]);
        craftables.Add(createrecipe(allItems[0], allItems[2]), allItems[2]);
        craftables.Add(createrecipe(allItems[0], allItems[1]), allItems[2]);
        craftables.Add(createrecipe(allItems[0], allItems[0]), allItems[3]);
        craftables.Add(createrecipe(allItems[0], allItems[1], allItems[1]), allItems[3]);
        craftables.Add(createrecipe(allItems[2], allItems[3], allItems[3]), allItems[4]);
        craftables.Add(createrecipe(allItems[1], allItems[1], allItems[1]), allItems[4]);
        craftables.Add(createrecipe(allItems[0], allItems[1], allItems[1]), allItems[3]);
        // Example crafting logic
        List<Items> items = new List<Items>
        {
            allItems[0],
            allItems[1]
        };
        Items craftedItem = Craft(items);
        if (craftedItem != null)
        {
            Debug.Log("Crafted item: " + craftedItem.itemName);
        }
        else
        {
            Debug.Log("Crafting failed");
        }
    }

    // Crafting method using custom key type
    public Items Craft(List<Items> itemsToCraft)
    {
        // Create a CraftingRecipe instance based on the input items
        CraftingRecipe recipe = new CraftingRecipe(itemsToCraft);

        // Check if any recipe in craftables matches the required items
        foreach (var pair in craftables)
        {
            CraftingRecipe craftableRecipe = pair.Key;
            if (craftableRecipe.Equals(recipe))
            {
                return pair.Value; // Return the crafted item
            }
        }

        return null; // Recipe not found, crafting failed
    }

    public void crafting()
    {
        List<Items> organizedList = new List<Items>();
        for (int i = 0; i < inventorymanagement.instance.crafting.Length - 1; i++)
        {
            inventoryslots slot = inventorymanagement.instance.crafting[i];
            inventoryitem inventoryitem = slot.GetComponentInChildren<inventoryitem>();
            if (inventoryitem != null)
            {

                organizedList.Add(inventoryitem.item);
            }



        }
        if (organizedList.Count > 0)
        {
        organizedList = organizedList
        .Where(item => item != null && !string.IsNullOrEmpty(item.itemName))
        .OrderBy(item => item.itemName)
        .ToList();
        Items generatedItem = Craft(organizedList);
        if(generatedItem != null)
            {
        inventorymanagement.instance.Spawnnewitem(generatedItem,
            inventorymanagement.instance.crafting[inventorymanagement.instance.crafting.Length - 1]);
    
            }

        }
}
}
