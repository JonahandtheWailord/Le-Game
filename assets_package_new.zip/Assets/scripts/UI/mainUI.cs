using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class mainUI : MonoBehaviour
{
    public static int money = 5;
    public Items startingitem;
    // Start is called before the first frame update
    void Start()
    {
        inventorymanagement.instance.AddItem(startingitem, inventorymanagement.instance.storage);
    }

    // Update is called once per frame
    void Update()
    {
        GameObject.Find("money").GetComponent<TextMeshProUGUI>().text = "money: " + money;
    }
}
