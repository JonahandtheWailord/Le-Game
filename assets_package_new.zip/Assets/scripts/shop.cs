using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shop : MonoBehaviour
{
    public Items[] shopitems;
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < shopitems.Length; i++)
        {
            inventorymanagement.instance.AddItem(shopitems[i], inventorymanagement.instance.shop);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
