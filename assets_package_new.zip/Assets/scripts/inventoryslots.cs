using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class inventoryslots : MonoBehaviour, IDropHandler
{
    public Image image;
    public Color selectedcolor, notselectedcolor;

    private void Awake()
    {
        deselect();
    }

    public void select()
    {
        image.color = selectedcolor;
    }

    public void deselect()
    {
        image.color =notselectedcolor;
    }

    public void OnDrop(PointerEventData eventData)
    {
        Debug.Log(eventData.pointerDrag.name);
        if(transform.childCount == 0)
        {


            inventoryitem inventoryitme = eventData.pointerDrag.GetComponent<inventoryitem>();
            Items item = inventoryitme.item;
            //checks to see if youu are gettig something from the shop or are selling something
            if (transform.parent.parent.tag == "shop" && inventoryitme.rootafterdrag.tag != "shop")
            {
                mainUI.money += item.cost;
                Debug.Log("just checking that it actually goes here");
            }
            else if(inventoryitme.rootafterdrag.tag == "shop" && transform.parent.parent.tag != "shop")
            {
                mainUI.money -= item.cost;
            }
            inventoryitme.parentafterDrag = transform;
        }
        else if(transform.root.tag == "shop")
        {
            //inventoryslots slot = inventorymanagement.instance.inventoryslots[transform.GetSiblingIndex()];
            inventoryitem iteminslot = gameObject.GetComponentInChildren<inventoryitem>();
            Items item = iteminslot.item;
            mainUI.money -= item.cost;
            inventorymanagement.instance.AddItem(item, inventorymanagement.instance.shop);
            Destroy(gameObject);
        }
        Debug.Log(mainUI.money);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
