using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class inventorymanagement : MonoBehaviour
{
    public static inventorymanagement instance;
    public int maxstack = 4;

    public static Dictionary<string, Items> itemsdic = new Dictionary<string, Items>();
    public Items[] items;
    public inventoryslots[] inventoryslots;
    public inventoryslots[] shop;
    public inventoryslots[] crafting;
    public inventoryslots[] storage;
    public GameObject inventoryitemprefab;

    public int selectedslot = 0;
    public static bool holding = false;

    private void Awake()
    {
        instance = this;
        itemsdic.Add("ax", items[4]);
        itemsdic.Add("can", items[3]);
        itemsdic.Add("plant", items[2]);
        itemsdic.Add("seed", items[1]);
        itemsdic.Add("hoe", items[0]);
    }
    private void Start()
    {
        changeselectedlsot(1);
    }

    private void Update()
    {
        if(Input.inputString != null)
        {
            bool isNumber = int.TryParse(Input.inputString, out int number);
            if(isNumber && number > 0 && number < 7 )
            {
                changeselectedlsot(number - 1);
            }
        }
    }

    public Items GetSelectedItem(bool use)
    {
        inventoryslots slot = inventoryslots[selectedslot];
        inventoryitem iteminslot = slot.GetComponentInChildren<inventoryitem>();
        if(iteminslot != null)
        {
            Items item = iteminslot.item;
            if(use == true)
            {
                iteminslot.count--;
                iteminslot.RefreshCount();
                if(iteminslot.count <= 0 ) 
                {
                Destroy(iteminslot.gameObject);
                }
            }
            return item;
        }
        Debug.Log("no item recieved");
        return null; 
    }

    void changeselectedlsot(int newvalue)
    {
        if(selectedslot >= 0) {
            inventoryslots[selectedslot].deselect();
        }

        inventoryslots[newvalue].select();
        selectedslot = newvalue;
        test_info.holding(GetSelectedItem(false));
    }


    public static bool ContainsKey(string key)
    {
        return itemsdic.ContainsKey(key);
    }

    public static Items GetValue(string key)
    {
        if (itemsdic.ContainsKey(key))
            return itemsdic[key];
        else
            return null; // Or return an empty array or handle as needed
    }
    public bool AddItem(Items items, inventoryslots[] slots)
    {
       // Debug.Log(items.image);
        for (int i = 0; i < slots.Length; i++)
        {
            inventoryslots slot = slots[i];
            inventoryitem inventoryitem = slot.GetComponentInChildren<inventoryitem>();
            if (inventoryitem != null &&
                inventoryitem.item == items &&
                inventoryitem.count < maxstack &&
                inventoryitem.item.stacable == true)
            {
                inventoryitem.count++;
                inventoryitem.RefreshCount();
                return true;
            }
        }

        for (int i = 0; i < slots.Length; i++)
        {
            inventoryslots slot = slots[i];
            inventoryitem inventoryitem = slot.GetComponentInChildren<inventoryitem>();
            if(inventoryitem == null)
            {
                Spawnnewitem(items, slot);
                return true;
            }
        }
        Debug.Log("item not added");
        return false;
    }

    public void Spawnnewitem(Items items, inventoryslots slot)
    {
        GameObject mewitemgo = Instantiate(inventoryitemprefab, slot.transform);
        inventoryitem mewitem = mewitemgo.GetComponent<inventoryitem>();
        mewitem.Initializeditem(items);
    }
}
