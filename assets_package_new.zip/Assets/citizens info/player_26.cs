using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class player_26 : MonoBehaviour
{
    public Button buttonprefab;
    private static Button button;
    public GameObject interactionsprefab;
    public GameObject shopkeeperprefab;
    public GameObject craftprefab;

    private static bool firsttimemeeting = true;


    private static GameObject interaction;
    private static GameObject shopkeeper;
    private static GameObject craft;
    // Start is called before the first frame update
    void Start()
    {
        interaction = interactionsprefab;
        shopkeeper = shopkeeperprefab;
        craft = craftprefab;
        button = buttonprefab;
    }

    public static void characterdecision()
    {   Button option1 = Instantiate(button, interaction.transform);
        Button option2 = Instantiate(button, interaction.transform);
        RectTransform option2Transform = option2.GetComponent<RectTransform>();
        option2Transform.anchorMin = new Vector2(1f, 0f); // Bottom right corner
        option2Transform.anchorMax = new Vector2(1f, 0f); // Bottom right corner
        option2Transform.pivot = new Vector2(1f, 0f); // Bottom right corner
            interaction.transform.Find("conversation").GetComponent<TextMeshProUGUI>().text = "Would you like the maret or to brew something?";

            option1.GetComponentInChildren<TextMeshProUGUI>().text = "market";
            option1.onClick.AddListener(delegate { firsttimeclick1(); });

            option2.GetComponentInChildren<TextMeshProUGUI>().text = "brew something";
            option2.onClick.AddListener(delegate { firsttimeclick2(); });
            firsttimemeeting=false;
/*        else
        {
            interaction.transform.Find("conversation").GetComponent<TextMeshProUGUI>().text = "Second time something knew should pop up.";
            option1.GetComponentInChildren<TextMeshProUGUI>().text = "Currently doesn't do anything";
            option1.onClick.AddListener(delegate { secondtimeclick1(); });
            option2.GetComponentInChildren<TextMeshProUGUI>().text = "We just chill";
            option2.onClick.AddListener(delegate { secondtimeclick2(); });
        }*/

    }

    private static void firsttimeclick1()
    {
        interaction.SetActive(false);
        shopkeeper.SetActive(true);

    }

    private static void firsttimeclick2()
    {
        interaction.SetActive(false);
        craft.SetActive(true);
    }

    private static void secondtimeclick1() 
    {
        interaction.SetActive(false);
    }

    private static void secondtimeclick2() 
    {
        interaction.SetActive(false);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
