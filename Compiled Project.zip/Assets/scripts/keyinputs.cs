using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using static UnityEditor.Progress;

public class keyinputs : MonoBehaviour
{
    public Tilemap[] tilemap;

    public static Tilemap[] statictilemap;

    public TileBase[] placing;

    public GameObject inventorySlotPrefab; // Prefab/UI element representing an inventory slot

    public GameObject interactionsprefab;


    private void Start()
    {
        statictilemap = tilemap;
    }

    // Update is called once per frame
    void Update()
    {

        if (Keyboard.current.zKey.wasPressedThisFrame)
        {
            if (daynight.timepause)
            {
                Debug.Log("unpause");
                daynight.timepause = false;
            }
            else
            {
                Debug.Log("paused");
            daynight.timepause = true;
            }

        }
            if (Keyboard.current.qKey.wasPressedThisFrame)
        {
            // Convert the hit point to tile coordinates
            Vector3Int cellPosition = playercontroller.position;
            TileBase tile = playercontroller.tilebase;
            if (playercontroller.interacting == null)
            {                     
                    Vector3Int rbposition = tilemap[1].WorldToCell(playercontroller.rb.position);
                    planting.plantingplant(tilemap, rbposition, placing);

            }
            else
            {
                Items item = inventorymanagement.instance.GetSelectedItem(false);
                Debug.Log(playercontroller.interacting.gameObject.name);
                if (tile != null && playercontroller.interacting.gameObject.name == "items")
                {
                    Items pickeditem = inventorymanagement.GetValue(((Tile)tile).sprite.name);
                    bool added = inventorymanagement.instance.AddItem(pickeditem, inventorymanagement.instance.inventoryslots);
                    if (added)
                    {
                        tilemap[3].SetTile(cellPosition, null);
                        playercontroller.interacting = null;
                    }
                }

                else if (item.itemName == "Pickaxe" && playercontroller.interacting.gameObject.name == "rocks")
                {
                    tilemap[2].SetTile(cellPosition, null);
                    playercontroller.interacting = null;
                    Debug.Log(((Tile)tile).sprite.name);
                    Items pickeditem = inventorymanagement.GetValue(((Tile)tile).sprite.name);
                    bool added = inventorymanagement.instance.AddItem(pickeditem, inventorymanagement.instance.inventoryslots);
                    if (added)
                    {
                        tilemap[3].SetTile(cellPosition, null);
                        playercontroller.interacting = null;
                    }
                }

                else if (tile != null && playercontroller.interacting.gameObject.name == "people")
                {
                    interactionsprefab.SetActive(true);
                    Debug.Log(((Tile)tile).sprite.name);
                    if (((Tile)tile).sprite.name == "player_11")
                    {
                        player_26.characterdecision();
                    }
                    else if (((Tile)tile).sprite.name == "player_50")
                    {
                        player_50.characterdecision();
                    }
                    playercontroller.interacting = null;
                }
            }
        }
    }
}
